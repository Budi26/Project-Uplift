package project.mmkstore.mmkstore.setting;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    private static final String PREF_NAME = "MyAppPrefs";
    private static final String IS_LOGGED_IN = "IsLoggedIn";

    // Metode untuk menghapus data sesi dan token
    public void clearUserdata() {
        editor.clear(); // Hapus semua data sesi

        // Untuk contoh, kunci token dihapus
        editor.remove("your_firebase_auth_token_here");

        editor.apply();
    }

    public SessionManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
    }

    public void setLoggedIn(boolean isLoggedIn) {
        editor.putBoolean(IS_LOGGED_IN, isLoggedIn);
        editor.apply();
    }

    public boolean isLoggedIn() {
        return sharedPreferences.getBoolean(IS_LOGGED_IN, false);
    }

    public void clearToken() {
        editor.remove("your_firebase_auth_token_here");
        editor.apply();
    }
}
