package project.mmkstore.mmkstore;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

public class Admin extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    private FirebaseAuth mAuth;
    private Button btnScan;
    private TextView text_shoes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        Button tambah = findViewById(R.id.create_tambah);
        tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Admin.this, CreateToko.class));

            }
        });
        Button ubah = findViewById(R.id.create_ubah);
        ubah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Admin.this, Listdata_Admin.class));

            }
        });

        Button logoutButton = findViewById(R.id.logout_admin);

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Logout dari Firebase

                //mAuth.signOut();
                logout();

                // Tampilkan pesan toast
                Toast.makeText(Admin.this, "Login Succsessfully", Toast.LENGTH_SHORT).show();

                // Pindah ke halaman login (atau halaman lain yang sesuai)
                //startActivity(new Intent(Admin.this, Login_Admin.class));
                finish(); // Menutup activity saat ini



            }
        });

        bottomNavigationView = findViewById(R.id.nav_view_admin);
        bottomNavigationView.setSelectedItemId(R.id.navigation_produk);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.navigation_produk:


                        return true;
                    case R.id.navigation_pesanan:
                        startActivity(new Intent(getApplicationContext(), listdata_cart_admin.class));
                        overridePendingTransition(0,0);


                        return true;

                }
                return false;
            }
        });
    }


    private void logout() {
        // Hapus status login dari SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("loginStatus", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", false);
        editor.apply();



        Intent intent = new Intent(this, Login_Admin.class);
        startActivity(intent);
        finish();
    }
}