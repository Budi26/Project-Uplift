package project.mmkstore.mmkstore.setting

import android.content.Context
import android.content.SharedPreferences

class ThemePreferences(context: Context) {
    private val prefName = "theme_prefs"
    private val keyIsDarkTheme = "is_dark_theme"
    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(prefName, Context.MODE_PRIVATE)

    fun isDarkTheme(): Boolean {
        return sharedPreferences.getBoolean(keyIsDarkTheme, false)
    }

    fun setDarkTheme(isDark: Boolean) {
        sharedPreferences.edit().putBoolean(keyIsDarkTheme, isDark).apply()
    }
}