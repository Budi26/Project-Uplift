package project.mmkstore.mmkstore;

import static android.text.TextUtils.isEmpty;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.UUID;

public class update_toko extends AppCompatActivity {
    private  String[] ListType, ListBrand;
    private EditText codeBaru, namaBaru, nohpBaru, emailBaru, priceBaru, addressBaru, newtgllahir;
    private Spinner new_Brand, new_Type;
    private ImageView fotolama;
    private ProgressBar progressBar;
    DatePickerDialog datePickerDialog;
    SimpleDateFormat dateFormatter, Formatedatalama;
    private RadioButton Pria, Wanita;
    private CheckBox golA, golB, golAB, golO;
    private Button update, btn_gantifoto,u_showdata;
    private DatabaseReference database;
    private StorageReference storageReference;
    private String cekCode, cekNama, cekBrand, cekNohp, cekEmail, cekPrice, cekAddress, cekType, cekgolongan, cekgender, cektgl, outputgolongan,outputjeniskelamin;

    private static  final int REQUEST_CODE_CAMERA = 1;
    private static  final int REQUEST_CODE_GALLERY = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_toko);
        //Edit Text ID
        codeBaru = findViewById(R.id.U_nama);
        namaBaru = findViewById(R.id.U_harga_barang);
        nohpBaru = findViewById(R.id.U_stok_barang);
        /*newtgllahir = findViewById(R.id.U_datebirth);
        nohpBaru = findViewById(R.id.U_nohp);
        emailBaru = findViewById(R.id.U_dataemail);
        priceBaru = findViewById(R.id.U_price);
        addressBaru = findViewById(R.id.U_address);

        //Spinner ID
        new_Brand = findViewById(R.id.U_brand);
        new_Type = findViewById(R.id.U_type);

        //CheckBox ID
        golA = findViewById(R.id.U_golA);
        golB = findViewById(R.id.U_golB);
        golAB = findViewById(R.id.U_golAB);
        golO = findViewById(R.id.U_golO);

        //RadioButton ID
        Pria = findViewById(R.id.U_pria);
        Wanita = findViewById(R.id.U_wanita);*/

        //Button ID
        btn_gantifoto = findViewById(R.id.U_getfoto_toko);
        update = findViewById(R.id.U_save_toko);
        u_showdata = findViewById(R.id.U_showdata_toko);


        //Gambar image view
        fotolama = findViewById(R.id.U_barang);

        //ProgressBar ID
        progressBar = findViewById(R.id.U_progress_toko);
        progressBar.setVisibility(View.GONE);

        //Mendapatkan Refrensi DataBase
        storageReference = FirebaseStorage.getInstance().getReference();
        database = FirebaseDatabase.getInstance().getReference();

        //Mendapatkan data dari firebase
        getData();

        //Fungsi dari Button
        btn_gantifoto.setOnClickListener(view ->{
            getImage();
        });
        u_showdata.setOnClickListener(view -> {
            onBackPressed();
        });

        update.setOnClickListener(view ->{
            //Mendapatkan Data dari firebase lalu di set kedalam variabel
            cekCode = codeBaru.getText().toString();
            cekNama = namaBaru.getText().toString();
            cekNohp = nohpBaru.getText().toString();
            /*cekBrand = new_Brand.getSelectedItem().toString();
            cekType = new_Type.getSelectedItem().toString();

            cekEmail = emailBaru.getText().toString();
            cekPrice = priceBaru.getText().toString();
            cekAddress = addressBaru.getText().toString();
            cektgl = newtgllahir.getText().toString();*/

            //Mengecek apakah ada data yang kosong saat sebelum dilakukan update
            if (isEmpty(cekCode)||isEmpty(cekNama) ||isEmpty(cekNohp) /*||isEmpty(cekEmail) ||isEmpty(cekBrand)|isEmpty(cekPrice)||outputgolongan == null || outputjeniskelamin==null||isEmpty(cekAddress)
                    ||isEmpty(cekType)||isEmpty(cektgl)*/){
                Toast.makeText(update_toko.this, "Data tidak boleh ada yang kosong ", Toast.LENGTH_SHORT).show();
            } else {
                //Jika tidak ada data yang kosong maka akan menjalankan proses berikut
                progressBar.setVisibility(View.VISIBLE);
                //Mendapatkan data dari Image view sebagai Bytes
                fotolama.setDrawingCacheEnabled(true);
                Bitmap bitmap = ((BitmapDrawable) fotolama.getDrawable()).getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();

                //Mengkompres Bitmap menjadi JPG
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
                byte[] bytes = stream.toByteArray();

                //Lokasi Lengkap dimana gambar disimpan
                String namafile = UUID.randomUUID()+".jpg";
                final String pathImage = "foto/"+namafile;
                UploadTask uploadTask = storageReference.child(pathImage).putBytes(bytes);
                uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        taskSnapshot.getStorage().getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                data_crud setDataShoes = new data_crud();
                                setDataShoes.setCode(codeBaru.getText().toString());
                                setDataShoes.setName(namaBaru.getText().toString());
                                setDataShoes.setNohp(nohpBaru.getText().toString());
                                //setDataShoes.setDataemail(emailBaru.getText().toString());
                                /*setDataShoes.setBrand(new_Brand.getSelectedItem().toString());
                                setDataShoes.setType(new_Type.getSelectedItem().toString());

                                setDataShoes.setPrice(priceBaru.getText().toString());
                                setDataShoes.setAddress(addressBaru.getText().toString());
                                setDataShoes.setHasilgol(outputgolongan.trim());
                                setDataShoes.setGender(outputjeniskelamin.trim());
                                setDataShoes.setTgllahir(newtgllahir.getText().toString());*/
                                setDataShoes.setGambar(uri.toString().trim());
                                startActivity(new Intent(update_toko.this, Listdata_Admin.class));
                                finish();

                                updateDataShoes(setDataShoes);
                            }
                        });
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(update_toko.this, "Upload Gagal", Toast.LENGTH_SHORT).show();
                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {
                        progressBar.setVisibility(View.VISIBLE);
                        double progres = (100.0 * snapshot.getBytesTransferred()) / snapshot.getTotalByteCount();
                        progressBar.setProgress((int) progres);
                    }
                });
            }

        });

    }

    //GetData
    public  void getData() {
        //Menampilkan data dari item yang dipilih sebelumnya
        final String getCode = getIntent().getExtras().getString("dataCode");
        final String getNama = getIntent().getExtras().getString("dataName");
        final String getBrand = getIntent().getExtras().getString("dataBrand");
        final String getNohp = getIntent().getExtras().getString("dataNohp");
        final String getEmail = getIntent().getExtras().getString("dataEmail");
        final String getPrice = getIntent().getExtras().getString("dataPrice");
        final String getAddress = getIntent().getExtras().getString("dataAddress");
        final String getType = getIntent().getExtras().getString("dataType");
        final String getHasilgol = getIntent().getExtras().getString("dataGol_dar");
        final String getGender = getIntent().getExtras().getString("dataGender");
        final String getTgl = getIntent().getExtras().getString("dataTgl");
        final String getGambar = getIntent().getExtras().getString("dataGambar");

        //Mengatur tampilan gambar
        if (isEmpty(getGambar)) {
            //foto lama = image view
            fotolama.setImageResource(R.drawable.image_placeholder);
        } else {
            Glide.with(update_toko.this)
                    .load(getGambar)
                    .into(fotolama);
        }
        /*golA.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    golB.setChecked(false);
                    golAB.setChecked(false);
                    golO.setChecked(false);
                    outputgolongan = "A";
                }
            }
        });
        golB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    golA.setChecked(false);
                    golAB.setChecked(false);
                    golO.setChecked(false);
                    outputgolongan = "B";
                }
            }
        });
        golAB.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    golA.setChecked(false);
                    golB.setChecked(false);
                    golO.setChecked(false);
                    outputgolongan = "AB";
                }
            }
        });
        golO.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    golA.setChecked(false);
                    golAB.setChecked(false);
                    golB.setChecked(false);
                    outputgolongan = "O";
                }
            }
        });

        ListType = new String[]{"FOOTBALL", "SPORTS", "FUTSAL", "SNEAKERS"};
        ArrayAdapter<String> typeadapter = new ArrayAdapter<>(this,
                androidx.constraintlayout.widget.R.layout.support_simple_spinner_dropdown_item, ListType);
        new_Type.setAdapter(typeadapter);
        new_Type.setSelection(typeadapter.getPosition(getType.trim()));

        ListBrand = new String[]{"NIKE", "ADIDASS", "PUMA", "SPECS", "ORTUSEIGHT"};
        ArrayAdapter<String> brandadapter = new ArrayAdapter<>(this,
                androidx.constraintlayout.widget.R.layout.support_simple_spinner_dropdown_item, ListBrand);
        new_Brand.setAdapter(brandadapter);
        new_Brand.setSelection(brandadapter.getPosition(getBrand.trim()));

        Pria.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    outputjeniskelamin = "Pria";
                }
            }
        });

        Wanita.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    outputjeniskelamin = "Wanita";
                }
            }
        });
        //mengatur DatePicker
        dateFormatter = new SimpleDateFormat("dd MM yyyy");
        newtgllahir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDataDialog();
            }
        });

        if (getHasilgol.trim().toString().equals("A")){
            golA.setChecked(true);
        } else if (getHasilgol.trim().toString().equals("B")){
            golB.setChecked(true);
        } else if (getHasilgol.trim().toString().equals("AB")) {
            golAB.setChecked(true);
        } else if (getHasilgol.trim().toString().equals("O")) {
            golO.setChecked(true);
        }

        if (getGender.trim().equals("Pria")){
            Pria.setChecked(true);
        } else if (getGender.trim().equals("Wanita")) {
            Wanita.setChecked(true);
        }*/

        codeBaru.setText(getCode);
        namaBaru.setText(getNama);
        nohpBaru.setText(getNohp);
        //emailBaru.setText(getEmail);
        //priceBaru.setText(getPrice);
        //addressBaru.setText(getAddress);
        //newtgllahir.setText(getTgl);
    }
    //Get Image
    private void getImage(){
        Intent imageIntentGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(imageIntentGallery, REQUEST_CODE_GALLERY);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        switch (requestCode){
            case REQUEST_CODE_CAMERA:
                break;
            case REQUEST_CODE_GALLERY:
                if (resultCode == RESULT_OK){
                    fotolama.setVisibility(View.VISIBLE);
                    Uri uri = data.getData();
                    fotolama.setImageURI(uri);
                }
                break;
        }
    }
    //Tanggal
    /*private void showDataDialog(){
        Calendar calendar = Calendar.getInstance();
        datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                Calendar newdate = Calendar.getInstance();
                newdate.set(year,month,dayOfMonth);
                newtgllahir.setText(dateFormatter.format(newdate.getTime()));
            }
        },calendar.get(Calendar.YEAR),calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
    }*/
    //Proses Update ke Firebase
    private void updateDataShoes(data_crud setDataShoes){
        progressBar.setVisibility(View.GONE);
        String getKey = getIntent().getExtras().getString("dataPrimaryKey");
        database.child("Admin")
                .child("MMK STORE")
                .child(getKey)
                .setValue(setDataShoes)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void avoid) {
                        codeBaru.setText("");
                        namaBaru.setText("");
                        nohpBaru.setText("");
                        /*emailBaru.setText("");
                        priceBaru.setText("");
                        addressBaru.setText("");
                        newtgllahir.setText("");*/
                        Toast.makeText(update_toko.this, "Data Berhasil di Update", Toast.LENGTH_SHORT).show();
                    }
                });
    }

}
