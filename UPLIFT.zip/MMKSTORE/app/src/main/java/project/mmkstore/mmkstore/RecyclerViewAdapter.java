package project.mmkstore.mmkstore;

import static android.text.TextUtils.isEmpty;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>implements Filterable {

    //Deklarasi variabel

    DatabaseReference dbF;
    StorageReference dbS;
    ArrayList<data_crud> listDataShoes;
    listdata context;
    ArrayList<data_crud> listDataShoesSearch;



    public interface dataListener{
        void onDelete(data_crud data, int position);
    }
    dataListener listener;





    Filter setSearch = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<data_crud> filterDataShoes = new ArrayList<>();
            if (constraint == null || constraint.length() == 0){
                filterDataShoes.addAll(listDataShoesSearch);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (data_crud item : listDataShoesSearch){
                    if (item.getCode().toLowerCase().contains(filterPattern)){
                        filterDataShoes.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filterDataShoes;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            listDataShoes.clear();
            listDataShoes.addAll((List) results.values);
            notifyDataSetChanged();

        }
    };

    //membuat konstruktor untuk menyimpan data
    public RecyclerViewAdapter(ArrayList<data_crud> listDataShoes, listdata context){
        this.listDataShoes = listDataShoes;
        this.context = context;
        listener = (listdata) context;
        this.listDataShoesSearch = listDataShoes;

    }

    @Override
    public Filter getFilter() {

        return setSearch;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewdesign_toko, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        final String Code = listDataShoes.get(position).getCode();
        final String Name = listDataShoes.get(position).getName();
        final String Nohp = listDataShoes.get(position).getNohp();
        final String Gambar = listDataShoes.get(position).getGambar();

        //Memasukan nilai kedalam  View (text View : Code, Nama, Brand)
        holder.Code.setText(": " + Code);
        holder.Name.setText(": " + Name);
        holder.Nohp.setText(": " + Nohp);



        if (isEmpty(Gambar)) {
            holder.Gambar.setImageResource(R.drawable.image_placeholder);
        } else {
            Glide.with(holder.itemView.getContext()).load(Gambar.trim()).into(holder.Gambar);
        }

        //mendapatkan referensi dari DataBase storage
        dbS = FirebaseStorage.getInstance().getReference();

        //mendapatkan Referensi dari DataBase Firebase
        dbF = FirebaseDatabase.getInstance().getReference();


        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(holder.itemView.getContext(), Detail_Activity.class);

            // Kirim data tentang item yang diklik ke Detail_Activity

            intent.putExtra("hero_foto", listDataShoes.get(position).getGambar());
            intent.putExtra("hero_name", listDataShoes.get(position).getCode());
            intent.putExtra("hero_description", listDataShoes.get(position).getName());
            intent.putExtra("stok_barang", listDataShoes.get(position).getNohp());
            // Anda dapat mengirim data lainnya sesuai kebutuhan

            // Mulai DetailActivity
            holder.itemView.getContext().startActivity(intent);
            Toast.makeText(holder.itemView.getContext(), "Kamu memilih " + listDataShoes.get(holder.getAdapterPosition()).getCode(), Toast.LENGTH_SHORT).show();
        });



        holder.Beli.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Menggunakan Intent untuk membuka kelas lain
                Intent intent = new Intent(context, Chekout.class);
                // Mengirim data ke Chekout Activity
                intent.putExtra("hero_code", listDataShoes.get(position).getCode());
                intent.putExtra("hero_name", listDataShoes.get(position).getName());
                context.startActivity(intent);

            }
        });
    }





    @Override
    public int getItemCount() {
        return listDataShoes.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView Code, Name, Brand, Goldar, Gender, Tgllahir, Nohp, Crudemail, Price,Address, Type;
        private ImageView Gambar;
        private Button Beli;
        private LinearLayout ListItem;
        public ViewHolder(@NonNull View itemView) {

            super(itemView);
            //meninginiliasisai view view pada layout recylerview
            Code = itemView.findViewById(R.id.viewnama);
            Name = itemView.findViewById(R.id.viewharga);
            Nohp = itemView.findViewById(R.id.stok_user);
            ListItem = itemView.findViewById(R.id.listdesign);
            Gambar = itemView.findViewById(R.id.gambar_viewdesign);
            Beli = itemView.findViewById(R.id.beli1);
        }
    }
}
