package project.mmkstore.mmkstore.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import project.mmkstore.mmkstore.R;
import project.mmkstore.mmkstore.SliderAdapter;

public class HomeFragment extends Fragment {

    private ViewPager2 viewPager;
    private SliderAdapter sliderAdapter;
    private int[] slideImages = {R.drawable.minyak, R.drawable.gulapasir, R.drawable.beras};




    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        /*viewPager = rootView.findViewById(R.id.viewPager);
        sliderAdapter = new SliderAdapter(requireContext(), slideImages);
        viewPager.setAdapter(sliderAdapter);
*/
        return rootView;

    }
}
