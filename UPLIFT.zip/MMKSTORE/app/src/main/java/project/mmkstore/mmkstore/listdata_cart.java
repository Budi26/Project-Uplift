package project.mmkstore.mmkstore;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;

public class listdata_cart extends AppCompatActivity implements RecyclerViewAdapter_cart.dataListener {

    private RecyclerView recyclerView;
    RecyclerViewAdapter_cart adapter;
    private RecyclerView.LayoutManager layoutManager;

    private DatabaseReference reference;
    private ArrayList<data_crud> data_crud;

    private FloatingActionButton fab, home;

    private EditText searchView;
    BottomNavigationView bottomNavigationView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listdata_cart);
        recyclerView = findViewById(R.id.datalist_cart);

        bottomNavigationView = findViewById(R.id.nav_view);
        bottomNavigationView.setSelectedItemId(R.id.navigation_cart);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.navigation_dashboard:
                        startActivity(new Intent(getApplicationContext(), Dashboard.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_home:
                        startActivity(new Intent(getApplicationContext(), listdata.class));
                        overridePendingTransition(0,0);

                        return true;
                    case R.id.navigation_cart:


                        return true;
                }
                return false;
            }
        });
        /*fab = findViewById(R.id.fab);
        home = findViewById(R.id.home1);*/

        //memanggil method GetData dari Firebase
        GetData("");

        searchView = findViewById(R.id.listcart_etsearch);
        searchView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().isEmpty()) {
                    GetData(s.toString());
                } else {
                    adapter.getFilter().filter(s);
                }

            }
        });

        //memanggil method
        MyRecyclerView();

        /*fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(listdata.this, DataShoes.class);
                startActivity(intent);
            }
        });

        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(listdata.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });*/

    }

    @Override
    public void onDelete(project.mmkstore.mmkstore.data_crud data, int position) {
        if (reference != null) {
            reference.child("Admin")
                    .child("Data Pesanan")
                    .child(data.getKey())
                    .removeValue()
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(listdata_cart.this, "Data Berhasil di Hapus", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }


    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {
        super.onPointerCaptureChanged(hasCapture);
    }

    private void GetData(String data) {
        reference = FirebaseDatabase.getInstance().getReference();
        reference.child("Admin").child("Data Pesanan").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                data_crud = new ArrayList<>();
                data_crud.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    data_crud Shoes = snapshot.getValue(project.mmkstore.mmkstore.data_crud.class);

                    Shoes.setKey(snapshot.getKey());
                    data_crud.add(Shoes);
                }

                // Balikkan urutan data agar data terbaru muncul di paling atas
                Collections.reverse(data_crud);

                adapter = new RecyclerViewAdapter_cart(data_crud, listdata_cart.this);
                adapter.notifyDataSetChanged();
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(getApplicationContext(), "Data gagal dimuat", Toast.LENGTH_SHORT).show();
                Log.e("MyListActivity", error.getDetails() + " " + error.getMessage());

            }

        });
    }

    private void MyRecyclerView() {
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);

        //membuat underline pada setiap item dalam list
        DividerItemDecoration ItemDecoration = new DividerItemDecoration(getApplicationContext(), DividerItemDecoration.VERTICAL);
        ItemDecoration.setDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.line));
        recyclerView.addItemDecoration(ItemDecoration);
    }



    /*@Override
    public void onDelete(project.mmkstore.mmkstore.data_crud data, int position) {
        if (reference != null) {
            reference.child("Admin")
                    .child("Data Pesanan")
                    .child(data.getKey())
                    .removeValue()
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(listdata_cart.this, "Data Berhasil di Hapus", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }*/
}
