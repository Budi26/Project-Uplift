package project.mmkstore.mmkstore;

import static android.text.TextUtils.isEmpty;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class RecyclerViewAdapter_cart extends RecyclerView.Adapter<RecyclerViewAdapter_cart.ViewHolder>implements Filterable {

    //Deklarasi variabel

    DatabaseReference dbF;
    StorageReference dbS;
    ArrayList<data_crud> listDataShoes;
    listdata_cart context;
    ArrayList<data_crud> listDataShoesSearch;

    public interface dataListener{
        void onDelete(data_crud data, int position);
    }
    dataListener listener;



    Filter setSearch = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            ArrayList<data_crud> filterDataShoes = new ArrayList<>();
            if (constraint == null || constraint.length() == 0){
                filterDataShoes.addAll(listDataShoesSearch);
            } else {
                String filterPattern = constraint.toString().toLowerCase().trim();
                for (data_crud item : listDataShoesSearch){
                    if (item.getName().toLowerCase().contains(filterPattern)){
                        filterDataShoes.add(item);
                    }
                }
            }
            FilterResults results = new FilterResults();
            results.values = filterDataShoes;
            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
            listDataShoes.clear();
            listDataShoes.addAll((List) results.values);
            notifyDataSetChanged();

        }
    };

    //membuat konstruktor untuk menyimpan data
    public RecyclerViewAdapter_cart(ArrayList<data_crud> listDataShoes, listdata_cart context){
        this.listDataShoes = listDataShoes;
        this.context = context;
        listener = (listdata_cart) context;
        this.listDataShoesSearch = listDataShoes;

    }

    @Override
    public Filter getFilter() {

        return setSearch;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewdesign_cart, parent, false);

        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        final String Name = listDataShoes.get(position).getName();
        final String Code = listDataShoes.get(position).getCode();
        final String Price = listDataShoes.get(position).getPrice();
        final String Nohp = listDataShoes.get(position).getNohp();
        final String Address = listDataShoes.get(position).getAddress();
        final String Gambar = listDataShoes.get(position).getGambar();
        final String Tgllahir = listDataShoes.get(position).getTgllahir();
        final String Brand = listDataShoes.get(position).getBrand();
        //final String Type = listDataShoes.get(position).getType();
        //final String Goldar = listDataShoes.get(position).getHasilgol();
        final String Gender = listDataShoes.get(position).getGender();


        //final String Crudemail = listDataShoes.get(position).getDataemail();




        //Memasukan nilai kedalam  View (text View : Code, Nama, Brand)

        holder.Name.setText(": " + Name);
        holder.Code.setText(": " + Code);
        holder.Price.setText(": " + Price);
        holder.Nohp.setText(": " + Nohp);
        holder.Tgllahir.setText(": " + Tgllahir);
        holder.Brand.setText(": " + Brand);
        holder.Gender.setText(": " + Gender);
        //holder.Type.setText(": " + Type);
        //holder.Goldar.setText(": " + Goldar);



        //holder.Crudemail.setText(": " + Crudemail);

        holder.Address.setText(": " + Address);

        if (isEmpty(Gambar)) {
            holder.Gambar.setImageResource(R.drawable.image_placeholder);
        } else {
            Glide.with(holder.itemView.getContext()).load(Gambar.trim()).into(holder.Gambar);
        }

        //mendapatkan referensi dari DataBase storage
        dbS = FirebaseStorage.getInstance().getReference();

        //mendapatkan Referensi dari DataBase Firebase
        dbF = FirebaseDatabase.getInstance().getReference();




        /*holder.ListItem.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(final View v) {
                final String[] action = {"Update", "Delete"};
                AlertDialog.Builder alert = new AlertDialog.Builder(v.getContext());
                alert.setTitle("Apa yang akan anda pilih?");
                alert.setItems(action, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        switch (i) {
                            case 0:
                                Bundle bundle = new Bundle();
                                bundle.putString("dataCode", listDataShoes.get(position).getCode());
                                bundle.putString("dataName", listDataShoes.get(position).getName());
                                bundle.putString("dataBrand", listDataShoes.get(position).getBrand());
                                bundle.putString("dataGol_dar", listDataShoes.get(position).getHasilgol());
                                bundle.putString("dataGender", listDataShoes.get(position).getGender());
                                bundle.putString("dataTgl", listDataShoes.get(position).getTgllahir());
                                bundle.putString("dataNohp", listDataShoes.get(position).getNohp());
                                bundle.putString("dataEmail", listDataShoes.get(position).getDataemail());
                                bundle.putString("dataPrice", listDataShoes.get(position).getPrice());
                                bundle.putString("dataAddress", listDataShoes.get(position).getAddress());
                                bundle.putString("dataPrimaryKey", listDataShoes.get(position).getKey());
                                bundle.putString("dataType", listDataShoes.get(position).getType());
                                bundle.putString("dataGambar", listDataShoes.get(position).getGambar());

                                Intent intent = new Intent(v.getContext(), update_cart.class);
                                intent.putExtras(bundle);
                                context.startActivity(intent);
                                break;

                            case 1:
                                AlertDialog.Builder alertt = new AlertDialog.Builder(v.getContext());
                                alertt.setTitle("Apakah anda yakin akan menghapus Data ini?");
                                alertt.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int i) {
                                       listener.onDelete(listDataShoes.get(position),position);
                                    }
                                });
                                alertt.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //menutup dialog hapus data
                                        return;
                                    }
                                });
                                alertt.create();
                                alertt.show();

                        }
                    }
                });
                alert.create();
                alert.show();
                return true;
            }

        });*/
    }





    @Override
    public int getItemCount() {
        return listDataShoes.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView Code, Name, Brand, Goldar, Gender, Tgllahir, Nohp, Crudemail, Price,Address, Type;
        private ImageView Gambar;
        private LinearLayout ListItem;
        public ViewHolder(@NonNull View itemView) {

            super(itemView);
            //meninginiliasisai view view pada layout recylerview

            Name = itemView.findViewById(R.id.viewcart_nama);
            Code = itemView.findViewById(R.id.viewcart_barang);
            Price = itemView.findViewById(R.id.viewcart_harga);
            Nohp = itemView.findViewById(R.id.viewcart_nohp);
            Address = itemView.findViewById(R.id.viewcart_alamat);
            Gambar = itemView.findViewById(R.id.viewcart_gambar);
            Tgllahir = itemView.findViewById(R.id.viewcart_tgl);
            Brand = itemView.findViewById(R.id.viewcart_status);
            //Type = itemView.findViewById(R.id.viewtype);
            //Goldar = itemView.findViewById(R.id.viewgol);
            Gender = itemView.findViewById(R.id.viewcart_metodebayar);


            //Crudemail = itemView.findViewById(R.id.viewemail);


            ListItem = itemView.findViewById(R.id.listdesign_cart);

        }
    }
}
