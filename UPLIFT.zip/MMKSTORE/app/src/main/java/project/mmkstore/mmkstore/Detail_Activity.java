package project.mmkstore.mmkstore;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class Detail_Activity extends AppCompatActivity {
    private TextView codeTextView, nameTextView;
    private ImageView gambarImageView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        // Ambil data yang dikirimkan dari ListHeroAdapter
        Intent intent = getIntent();
        String heroPhotoUrl = intent.getStringExtra("hero_foto");
        String heroName = intent.getStringExtra("hero_name");
        String heroDescription = intent.getStringExtra("hero_description");
        String stokbarang = intent.getStringExtra("stok_barang");
        //String desBarang = intent.getStringExtra("deskripsi_barang");

        // Tampilkan data di tampilan DetailActivity
        ImageView fotopemain = findViewById(R.id.foto_pemain);
        TextView nameTextView = findViewById(R.id.nama_pemain);
        TextView descriptionTextView = findViewById(R.id.des_pemain);
        TextView stokTextView = findViewById(R.id.det_stok);
        //TextView DesTextView = findViewById(R.id.det_des);



        nameTextView.setText(heroName);
        descriptionTextView.setText(heroDescription);
        stokTextView.setText(stokbarang);
        //DesTextView.setText(desBarang);

        if (heroPhotoUrl != null) {
            Glide.with(this)
                    .load(heroPhotoUrl)
                    .into(fotopemain);
        }
    }
}
