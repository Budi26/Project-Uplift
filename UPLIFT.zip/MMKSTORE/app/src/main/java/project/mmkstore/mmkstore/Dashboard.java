package project.mmkstore.mmkstore;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;

import project.mmkstore.mmkstore.setting.SettingActivity;

public class Dashboard extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    private FirebaseAuth mAuth;
    private ImageView logoutButton, add_admin,riwayat,setelan,user_dash, cart_dash;
    //private InterstitialAd mInterstitialAd;
    //private RewardedAd rewardedAd;
    private final String TAG = "MainActivity";



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

//        AdRequest adRequest1 = new AdRequest.Builder().build();
//        RewardedAd.load(this, "ca-app-pub-3940256099942544/5224354917",
//                adRequest1, new RewardedAdLoadCallback() {
//                    @Override
//                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
//                        // Handle the error.
//                        Log.d(TAG, loadAdError.toString());
//                        rewardedAd = null;
//                    }
//
//                    @Override
//                    public void onAdLoaded(@NonNull RewardedAd ad) {
//                        rewardedAd = ad;
//                        Log.d(TAG, "Ad was loaded.");
//                    }
//                });
//
//        AdRequest adRequest = new AdRequest.Builder().build();
//        InterstitialAd.load(this,"ca-app-pub-3940256099942544/1033173712", adRequest,
//                new InterstitialAdLoadCallback() {
//                    @Override
//                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
//                        // The mInterstitialAd reference will be null until
//                        // an ad is loaded.
//                        mInterstitialAd = interstitialAd;
//                        Log.i(TAG, "onAdLoaded");
//                    }
//
//                    @Override
//                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
//                        // Handle the error
//                        Log.d(TAG, loadAdError.toString());
//                        mInterstitialAd = null;
//                    }
//                });

        FirebaseAuth mAuth = FirebaseAuth.getInstance();

        logoutButton = findViewById(R.id.logout);
        add_admin = findViewById(R.id.add_admin);
//        riwayat = findViewById(R.id.riwayat);
//        setelan = findViewById(R.id.setelan);
        user_dash = findViewById(R.id.user_dashboard);
        cart_dash =  findViewById(R.id.cart_dashboard);
        add_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Dashboard.this, Login_Admin.class));


            }
        });

        user_dash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Dashboard.this, SettingActivity.class));


            }
        });

        cart_dash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Dashboard.this, listdata_cart.class));


            }
        });

        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Logout dari Firebase
                mAuth.signOut();
                logout();

                // Tampilkan pesan toast
                Toast.makeText(Dashboard.this, "Login Succsessfully", Toast.LENGTH_SHORT).show();

                // Pindah ke halaman login (atau halaman lain yang sesuai)
                //startActivity(new Intent(Dashboard.this, Login.class));
                finish(); // Menutup activity saat ini



            }
        });
//        riwayat.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (mInterstitialAd != null) {
//                    mInterstitialAd.show(Dashboard.this);
//                } else {
//                    Log.d("TAG", "The interstitial ad wasn't ready yet.");
//                }
//
//
//            }
//        });
//        setelan.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                if (rewardedAd != null) {
//                    Activity activityContext = Dashboard.this;
//                    rewardedAd.show(activityContext, new OnUserEarnedRewardListener() {
//                        @Override
//                        public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
//                            // Handle the reward.
//                            Log.d(TAG, "The user earned the reward.");
//                            int rewardAmount = rewardItem.getAmount();
//                            String rewardType = rewardItem.getType();
//                        }
//                    });
//                } else {
//                    Log.d(TAG, "The rewarded ad wasn't ready yet.");
//                }
//
//
//
//            }
//        });


        bottomNavigationView = findViewById(R.id.nav_view);
        bottomNavigationView.setSelectedItemId(R.id.navigation_dashboard);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.navigation_dashboard:

                        return true;
                    case R.id.navigation_cart:
                        startActivity(new Intent(getApplicationContext(), listdata_cart.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.navigation_home:
                        startActivity(new Intent(getApplicationContext(), listdata.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });

    }
    /*@Override
    public boolean onOptionsItemSelected(@NonNull Dashboard item) {
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        switch (item.getItemId()) {
            case R.id.action_logout:
                // panggil metode logout
                mAuth.signOut();
                logout();
                Toast.makeText(Dashboard.this, "Logout Successfully", Toast.LENGTH_SHORT).show();
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }

    }*/
    private void logout() {
        // implementasi kode logout, misalnya:
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
        finish();
    }
}