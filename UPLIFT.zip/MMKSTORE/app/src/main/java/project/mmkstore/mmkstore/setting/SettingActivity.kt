package project.mmkstore.mmkstore.setting


import android.Manifest
import android.os.Build
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.preference.ListPreference
import androidx.preference.PreferenceFragmentCompat
import project.mmkstore.mmkstore.R
import project.mmkstore.mmkstore.databinding.ActivitySettingBinding

// ...


class SettingActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingBinding
    private lateinit var themePreferences: ThemePreferences



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingBinding.inflate(layoutInflater)
        setContentView(binding.root)


       themePreferences = ThemePreferences(this)

        // Inisialisasi SwitchMaterial
        val switchTheme = binding.switchTheme
        switchTheme.isChecked = themePreferences.isDarkTheme()
        val ivBack: ImageView = findViewById(R.id.ivBack1)

        switchTheme.setOnCheckedChangeListener { _, isChecked ->

            themePreferences.setDarkTheme(isChecked)
            // Terapkan perubahan tema ke seluruh aplikasi
            // Terapkan perubahan tema ke seluruh aplikasi
            recreate()


            applyTheme(isChecked)
        }
        ivBack.setOnClickListener {
            onBackPressed()
        }




        /*if (savedInstanceState == null) {
            supportFragmentManager
                .beginTransaction()
                .replace(R.id.settings, SettingsFragment())
                .commit()
            binding.apply {
                ivBack.setOnClickListener {
                    onBackPressed()
                }
            }
        }*/
    }

    /*class SettingsFragment : PreferenceFragmentCompat() {
        override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey)

            val themePreference = findPreference<ListPreference>(getString(R.string.pref_key_dark))
            themePreference?.setOnPreferenceChangeListener { _, newValue ->
                when (newValue) {
                    getString(R.string.pref_dark_auto) -> {
                        updateTheme(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
                    }
                    getString(R.string.pref_dark_on) -> {
                        updateTheme(AppCompatDelegate.MODE_NIGHT_YES)
                    }
                    getString(R.string.pref_dark_off) -> {
                        updateTheme(AppCompatDelegate.MODE_NIGHT_NO)
                    }
                }
                true
            }
        }

        private fun updateTheme(mode: Int): Boolean {
            AppCompatDelegate.setDefaultNightMode(mode)
            requireActivity().recreate()
            return true
        }
    }*/

    // Metode untuk menerapkan tema sesuai preferensi
    private fun applyTheme(isDarkMode: Boolean) {
        if (isDarkMode) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        }
    }


}


